Standfade Launcher
==================

Простой лаунчер:
- Проверяет наличие com.b3bl1.standfade
- Если нет — пишет "Скачайте Standfade"
- Если да — просит любой код
- После ввода кода запускает игру

Как собрать:
1. Открой папку в Android Studio
2. Дождись синхронизации Gradle
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. Готовый APK будет в app/build/outputs/apk/debug/

Package лаунчера: com.example.standfadelauncher
