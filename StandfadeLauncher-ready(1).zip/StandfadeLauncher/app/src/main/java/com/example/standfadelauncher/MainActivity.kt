package com.example.standfadelauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val TARGET_PACKAGE = "com.b3bl1.standfade"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val statusText = findViewById<TextView>(R.id.statusText)
        val codeInput = findViewById<EditText>(R.id.codeInput)
        val launchButton = findViewById<Button>(R.id.launchButton)

        if (!isAppInstalled(TARGET_PACKAGE)) {
            statusText.text = "Скачайте Standfade"
            codeInput.isEnabled = false
            launchButton.isEnabled = false
        } else {
            statusText.text = "Введите код"
            launchButton.setOnClickListener {
                val code = codeInput.text.toString().trim()
                if (code.isEmpty()) {
                    Toast.makeText(this, "Введите код", Toast.LENGTH_SHORT).show()
                } else {
                    // Любой непустой код принимается
                    launchApp(TARGET_PACKAGE)
                }
            }
        }
    }

    private fun isAppInstalled(packageName: String): Boolean {
        return try {
            packageManager.getPackageInfo(packageName, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    private fun launchApp(packageName: String) {
        val intent = packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            startActivity(intent)
        } else {
            Toast.makeText(this, "Не удалось запустить приложение", Toast.LENGTH_SHORT).show()
        }
    }
}
